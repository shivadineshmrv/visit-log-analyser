"""Core data model."""
from dataclasses import dataclass, asdict


@dataclass
class Visit:
    id: int
    date: str          # YYYY-MM-DD
    time: str          # HH:MM
    visitor_id: str
    page: str          # e.g. /pricing
    referrer: str      # normalized domain/keyword, "direct" if none
    duration_sec: int  # time on site in seconds

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Visit":
        return cls(
            id=int(d["id"]),
            date=str(d["date"]),
            time=str(d["time"]),
            visitor_id=str(d["visitor_id"]),
            page=str(d["page"]),
            referrer=str(d["referrer"]),
            duration_sec=int(d["duration_sec"]),
        )


FIELDS = ["id", "date", "time", "visitor_id", "page", "referrer", "duration_sec"]
IMPORT_FIELDS = ["date", "time", "visitor_id", "page", "referrer", "duration_sec"]
