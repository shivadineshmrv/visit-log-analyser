"""Local persistence (JSON primary store, CSV import/export) with corruption recovery."""
import csv
import json
import os
import shutil
from datetime import datetime
from typing import List, Tuple

from .models import Visit, FIELDS, IMPORT_FIELDS
from .validation import validate_row, ValidationError

SCHEMA_VERSION = 1


class Store:
    def __init__(self, path: str = "data/visits.json"):
        self.path = path
        self.visits: List[Visit] = []
        self.load_notice = ""
        self.load()

    # ---------- load / save ----------
    def load(self) -> None:
        self.visits = []
        self.load_notice = ""
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            records = payload["visits"] if isinstance(payload, dict) else payload
            self.visits = [Visit.from_dict(r) for r in records]
        except FileNotFoundError:
            self.load_notice = "No data file found - starting with an empty log."
            self.save()
        except (json.JSONDecodeError, KeyError, TypeError, ValueError):
            backup = f"{self.path}.corrupt-{datetime.now():%Y%m%d-%H%M%S}"
            try:
                shutil.copy(self.path, backup)
            except OSError:
                backup = "(backup failed)"
            self.visits = []
            self.load_notice = f"Data file was unreadable. Backed up to {backup}; started a clean log."
            self.save()

    def save(self) -> None:
        folder = os.path.dirname(self.path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"schema": SCHEMA_VERSION, "visits": [v.to_dict() for v in self.visits]}, fh, indent=2)
        os.replace(tmp, self.path)  # atomic: never leaves a half-written file

    # ---------- CRUD ----------
    def next_id(self) -> int:
        return max((v.id for v in self.visits), default=0) + 1

    def add(self, clean: dict) -> Visit:
        visit = Visit(id=self.next_id(), **clean)
        self.visits.append(visit)
        self.save()
        return visit

    def delete(self, visit_id: int) -> bool:
        before = len(self.visits)
        self.visits = [v for v in self.visits if v.id != visit_id]
        if len(self.visits) != before:
            self.save()
            return True
        return False

    def clear(self) -> None:
        self.visits = []
        self.save()

    def _key(self, d: dict) -> Tuple:
        return (d["date"], d["time"], d["visitor_id"], d["page"])

    # ---------- bulk CSV import ----------
    def import_csv(self, csv_path: str, error_log_path: str = "output/import_errors.log") -> Tuple[int, List[str]]:
        """Import rows; returns (added_count, error_lines). Never raises on bad rows."""
        errors: List[str] = []
        added = 0
        existing = {self._key(v.to_dict()) for v in self.visits}
        with open(csv_path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            headers = [h.strip().lower() for h in (reader.fieldnames or [])]
            missing = [f for f in IMPORT_FIELDS if f not in headers]
            if missing:
                raise ValidationError(f"CSV is missing required column(s): {', '.join(missing)}")
            for line_no, raw in enumerate(reader, start=2):  # header is line 1
                row = {(k or "").strip().lower(): (v or "") for k, v in raw.items()}
                try:
                    clean = validate_row(row)
                    key = self._key(clean)
                    if key in existing:
                        raise ValidationError("duplicate of an existing record")
                    existing.add(key)
                    self.visits.append(Visit(id=self.next_id(), **clean))
                    added += 1
                except ValidationError as exc:
                    errors.append(f"line {line_no}: {exc}")
        if added:
            self.save()
        if errors:
            folder = os.path.dirname(error_log_path)
            if folder:
                os.makedirs(folder, exist_ok=True)
            with open(error_log_path, "w", encoding="utf-8") as fh:
                fh.write(f"Import of {csv_path} at {datetime.now():%Y-%m-%d %H:%M:%S}\n")
                fh.write(f"{added} row(s) imported, {len(errors)} rejected\n\n")
                fh.write("\n".join(errors) + "\n")
        return added, errors

    # ---------- exports ----------
    def export_csv(self, path: str) -> None:
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=FIELDS)
            writer.writeheader()
            for v in self.visits:
                writer.writerow(v.to_dict())
