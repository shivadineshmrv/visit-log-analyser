"""Core business logic: summarize visits by day and referrer, search, trends, warnings."""
from collections import defaultdict
from statistics import mean, pstdev
from typing import Dict, List, Optional

from .models import Visit

BOUNCE_SECONDS = 10          # visits shorter than this count as a "bounce"
SPIKE_SIGMA = 2.0            # day is anomalous if > mean + 2 std-devs
DOMINANT_REFERRER_SHARE = 0.60
HIGH_BOUNCE_RATE = 0.40
LONG_SESSION_SECONDS = 3600


def by_day(visits: List[Visit]) -> List[dict]:
    """Per-day totals, sorted by date."""
    groups: Dict[str, List[Visit]] = defaultdict(list)
    for v in visits:
        groups[v.date].append(v)
    rows = []
    for day in sorted(groups):
        vs = groups[day]
        rows.append({
            "date": day,
            "visits": len(vs),
            "unique_visitors": len({v.visitor_id for v in vs}),
            "avg_duration": round(mean(v.duration_sec for v in vs), 1),
        })
    return rows


def by_referrer(visits: List[Visit]) -> List[dict]:
    """Per-referrer totals with share of traffic, sorted by visits (desc)."""
    total = len(visits)
    groups: Dict[str, List[Visit]] = defaultdict(list)
    for v in visits:
        groups[v.referrer].append(v)
    rows = []
    for ref, vs in groups.items():
        rows.append({
            "referrer": ref,
            "visits": len(vs),
            "share_pct": round(100 * len(vs) / total, 1) if total else 0.0,
            "unique_visitors": len({v.visitor_id for v in vs}),
            "avg_duration": round(mean(v.duration_sec for v in vs), 1),
        })
    rows.sort(key=lambda r: (-r["visits"], r["referrer"]))
    return rows


def day_referrer_matrix(visits: List[Visit]):
    """Returns (days, referrers, counts[day][referrer])."""
    counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for v in visits:
        counts[v.date][v.referrer] += 1
    days = sorted(counts)
    refs = [r["referrer"] for r in by_referrer(visits)]
    return days, refs, counts


def search(visits: List[Visit], keyword: str = "", referrer: str = "", page: str = "",
           date_from: str = "", date_to: str = "", min_duration: Optional[int] = None) -> List[Visit]:
    kw = keyword.strip().lower()
    out = []
    for v in visits:
        if kw and kw not in " ".join([v.visitor_id, v.page, v.referrer, v.date]).lower():
            continue
        if referrer and v.referrer != referrer:
            continue
        if page and page.lower() not in v.page.lower():
            continue
        if date_from and v.date < date_from:
            continue
        if date_to and v.date > date_to:
            continue
        if min_duration is not None and v.duration_sec < min_duration:
            continue
        out.append(v)
    return out


def _slope(values: List[float]) -> float:
    """Least-squares slope of values against 0..n-1."""
    n = len(values)
    if n < 2:
        return 0.0
    xs = range(n)
    mx, my = (n - 1) / 2, mean(values)
    den = sum((x - mx) ** 2 for x in xs)
    return sum((x - mx) * (y - my) for x, y in zip(xs, values)) / den if den else 0.0


def trend(daily: List[dict]) -> str:
    counts = [d["visits"] for d in daily]
    if len(counts) < 3:
        return "not enough data"
    slope, avg = _slope(counts), mean(counts)
    if avg and abs(slope) < 0.03 * avg:
        return "flat"
    return "rising" if slope > 0 else "falling"


def warnings(visits: List[Visit]) -> List[str]:
    """Threshold warning indicators."""
    out: List[str] = []
    if not visits:
        return out
    daily = by_day(visits)
    counts = [d["visits"] for d in daily]
    if len(counts) >= 3:
        mu, sd = mean(counts), pstdev(counts)
        if sd > 0:
            for d in daily:
                if d["visits"] > mu + SPIKE_SIGMA * sd:
                    out.append(f"Traffic spike on {d['date']}: {d['visits']} visits (avg {mu:.1f}).")
    refs = by_referrer(visits)
    if refs and refs[0]["share_pct"] / 100 > DOMINANT_REFERRER_SHARE:
        out.append(f"Single-source dependence: '{refs[0]['referrer']}' drives {refs[0]['share_pct']}% of visits.")
    bounce = sum(1 for v in visits if v.duration_sec < BOUNCE_SECONDS) / len(visits)
    if bounce > HIGH_BOUNCE_RATE:
        out.append(f"High bounce rate: {bounce:.0%} of visits lasted under {BOUNCE_SECONDS}s.")
    longs = [v for v in visits if v.duration_sec > LONG_SESSION_SECONDS]
    if longs:
        out.append(f"{len(longs)} unusually long session(s) over {LONG_SESSION_SECONDS // 60} min "
                   f"(IDs: {', '.join(str(v.id) for v in longs[:5])}) - possible bot or idle tab.")
    # gap days
    from datetime import date, timedelta
    present = {d["date"] for d in daily}
    first, last = date.fromisoformat(daily[0]["date"]), date.fromisoformat(daily[-1]["date"])
    missing = [(first + timedelta(n)).isoformat() for n in range((last - first).days + 1)
               if (first + timedelta(n)).isoformat() not in present]
    if missing:
        out.append(f"{len(missing)} day(s) with zero recorded visits: {', '.join(missing[:5])}"
                   f"{'...' if len(missing) > 5 else ''}.")
    return out


def executive_summary(visits: List[Visit]) -> dict:
    if not visits:
        return {"total_visits": 0}
    daily, refs = by_day(visits), by_referrer(visits)
    busiest = max(daily, key=lambda d: d["visits"])
    quietest = min(daily, key=lambda d: d["visits"])
    pages = defaultdict(int)
    for v in visits:
        pages[v.page] += 1
    top_page = max(pages.items(), key=lambda kv: (kv[1], kv[0]))
    return {
        "total_visits": len(visits),
        "unique_visitors": len({v.visitor_id for v in visits}),
        "days_covered": len(daily),
        "date_range": f"{daily[0]['date']} to {daily[-1]['date']}",
        "avg_visits_per_day": round(len(visits) / len(daily), 1),
        "avg_duration_sec": round(mean(v.duration_sec for v in visits), 1),
        "bounce_rate_pct": round(100 * sum(1 for v in visits if v.duration_sec < BOUNCE_SECONDS) / len(visits), 1),
        "busiest_day": f"{busiest['date']} ({busiest['visits']} visits)",
        "quietest_day": f"{quietest['date']} ({quietest['visits']} visits)",
        "top_referrer": f"{refs[0]['referrer']} ({refs[0]['share_pct']}%)",
        "top_page": f"{top_page[0]} ({top_page[1]} visits)",
        "trend": trend(daily),
        "warnings": warnings(visits),
    }
