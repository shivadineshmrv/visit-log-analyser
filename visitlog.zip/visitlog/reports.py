"""Report generation: text tables, Markdown, plain-text audit log, CSV summaries."""
import csv
import os
from datetime import datetime
from typing import List

from . import analytics
from .models import Visit
from .ui import table

DAY_HEADERS = ["Date", "Visits", "Unique", "Avg dur (s)"]
REF_HEADERS = ["Referrer", "Visits", "Share %", "Unique", "Avg dur (s)"]


def day_rows(visits):
    return [[d["date"], d["visits"], d["unique_visitors"], d["avg_duration"]] for d in analytics.by_day(visits)]


def ref_rows(visits):
    return [[r["referrer"], r["visits"], r["share_pct"], r["unique_visitors"], r["avg_duration"]]
            for r in analytics.by_referrer(visits)]


def matrix_text(visits: List[Visit], max_refs: int = 6) -> str:
    days, refs, counts = analytics.day_referrer_matrix(visits)
    shown = refs[:max_refs]
    headers = ["Date"] + shown + (["other"] if len(refs) > max_refs else []) + ["Total"]
    rows = []
    for d in days:
        row = [d] + [counts[d][r] for r in shown]
        if len(refs) > max_refs:
            row.append(sum(counts[d][r] for r in refs[max_refs:]))
        row.append(sum(counts[d].values()))
        rows.append(row)
    return table(headers, rows, max_width=14)


def summary_text(visits: List[Visit]) -> str:
    s = analytics.executive_summary(visits)
    if not s["total_visits"]:
        return "No data - the log is empty."
    labels = [
        ("Total visits", "total_visits"), ("Unique visitors", "unique_visitors"),
        ("Date range", "date_range"), ("Days covered", "days_covered"),
        ("Avg visits / day", "avg_visits_per_day"), ("Avg duration (s)", "avg_duration_sec"),
        ("Bounce rate (%)", "bounce_rate_pct"), ("Busiest day", "busiest_day"),
        ("Quietest day", "quietest_day"), ("Top referrer", "top_referrer"),
        ("Top page", "top_page"), ("Traffic trend", "trend"),
    ]
    lines = [f"{label:<20}: {s[key]}" for label, key in labels]
    lines.append("")
    lines.append("Warnings:" if s["warnings"] else "Warnings: none - all indicators within thresholds.")
    lines += [f"  ! {w}" for w in s["warnings"]]
    return "\n".join(lines)


def export_all(visits: List[Visit], out_dir: str = "output") -> List[str]:
    """Write Markdown, plain-text audit log and CSV summaries. Returns file paths."""
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    s = analytics.executive_summary(visits)
    paths = []

    # Markdown
    md_path = os.path.join(out_dir, f"report_{stamp}.md")
    with open(md_path, "w", encoding="utf-8") as fh:
        fh.write(f"# Website Visit Log Report\n\n_Generated {now}_\n\n")
        if not s["total_visits"]:
            fh.write("No data available.\n")
        else:
            fh.write("## Executive Summary\n\n| Metric | Value |\n|---|---|\n")
            for k in ("total_visits", "unique_visitors", "date_range", "avg_visits_per_day",
                      "avg_duration_sec", "bounce_rate_pct", "busiest_day", "top_referrer", "top_page", "trend"):
                fh.write(f"| {k.replace('_', ' ').title()} | {s[k]} |\n")
            fh.write("\n## Warnings\n\n")
            fh.write("\n".join(f"- {w}" for w in s["warnings"]) if s["warnings"] else "None.")
            fh.write("\n\n## Visits by Day\n\n| Date | Visits | Unique | Avg duration (s) |\n|---|---:|---:|---:|\n")
            for r in day_rows(visits):
                fh.write("| " + " | ".join(map(str, r)) + " |\n")
            fh.write("\n## Visits by Referrer\n\n| Referrer | Visits | Share % | Unique | Avg duration (s) |\n|---|---:|---:|---:|---:|\n")
            for r in ref_rows(visits):
                fh.write("| " + " | ".join(map(str, r)) + " |\n")
    paths.append(md_path)

    # Plain-text audit log
    txt_path = os.path.join(out_dir, f"audit_{stamp}.txt")
    with open(txt_path, "w", encoding="utf-8") as fh:
        fh.write(f"WEBSITE VISIT LOG - AUDIT\nGenerated: {now}\nRecords: {len(visits)}\n{'=' * 60}\n\n")
        fh.write(summary_text(visits) + "\n\n")
        if visits:
            fh.write("VISITS BY DAY\n" + table(DAY_HEADERS, day_rows(visits)) + "\n\n")
            fh.write("VISITS BY REFERRER\n" + table(REF_HEADERS, ref_rows(visits)) + "\n\n")
            fh.write("DAY x REFERRER\n" + matrix_text(visits) + "\n")
    paths.append(txt_path)

    # CSV summaries
    for name, headers, rows in (("by_day", DAY_HEADERS, day_rows(visits)),
                                ("by_referrer", REF_HEADERS, ref_rows(visits))):
        p = os.path.join(out_dir, f"summary_{name}_{stamp}.csv")
        with open(p, "w", encoding="utf-8", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(headers)
            w.writerows(rows)
        paths.append(p)
    return paths
