"""Matplotlib charts (saved as PNG). Degrades gracefully if matplotlib is missing."""
import os
from datetime import datetime
from typing import List

from . import analytics
from .models import Visit


def _plt():
    try:
        import matplotlib
        matplotlib.use("Agg")  # headless-safe: write files, no window needed
        import matplotlib.pyplot as plt
        return plt
    except ImportError:
        return None


def make_charts(visits: List[Visit], out_dir: str = "output") -> List[str]:
    """Create trend, referrer and stacked day x referrer charts. Returns file paths ([] if unavailable)."""
    plt = _plt()
    if plt is None or not visits:
        return []
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    paths = []

    daily = analytics.by_day(visits)
    days = [d["date"][5:] for d in daily]
    counts = [d["visits"] for d in daily]

    # 1. Daily trend
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(days, counts, marker="o", linewidth=2, label="Visits")
    avg = sum(counts) / len(counts)
    ax.axhline(avg, linestyle="--", color="gray", label=f"Average ({avg:.1f})")
    ax.set_title("Daily Visits")
    ax.set_xlabel("Date (MM-DD)")
    ax.set_ylabel("Visits")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout()
    p = os.path.join(out_dir, f"chart_daily_trend_{stamp}.png")
    fig.savefig(p, dpi=130)
    plt.close(fig)
    paths.append(p)

    # 2. Referrer distribution
    refs = analytics.by_referrer(visits)
    top = refs[:8]
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.barh([r["referrer"] for r in reversed(top)], [r["visits"] for r in reversed(top)], color="#3b82f6")
    for i, r in enumerate(reversed(top)):
        ax.text(r["visits"], i, f"  {r['share_pct']}%", va="center")
    ax.set_title("Visits by Referrer")
    ax.set_xlabel("Visits")
    fig.tight_layout()
    p = os.path.join(out_dir, f"chart_referrers_{stamp}.png")
    fig.savefig(p, dpi=130)
    plt.close(fig)
    paths.append(p)

    # 3. Stacked day x referrer
    dlist, rlist, matrix = analytics.day_referrer_matrix(visits)
    shown = rlist[:6]
    fig, ax = plt.subplots(figsize=(9, 4.8))
    bottom = [0] * len(dlist)
    for ref in shown:
        vals = [matrix[d][ref] for d in dlist]
        ax.bar([d[5:] for d in dlist], vals, bottom=bottom, label=ref)
        bottom = [b + v for b, v in zip(bottom, vals)]
    if len(rlist) > 6:
        vals = [sum(matrix[d][r] for r in rlist[6:]) for d in dlist]
        ax.bar([d[5:] for d in dlist], vals, bottom=bottom, label="other", color="lightgray")
    ax.set_title("Visits by Day and Referrer")
    ax.set_xlabel("Date (MM-DD)")
    ax.set_ylabel("Visits")
    ax.legend(fontsize=8, ncol=2)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout()
    p = os.path.join(out_dir, f"chart_day_by_referrer_{stamp}.png")
    fig.savefig(p, dpi=130)
    plt.close(fig)
    paths.append(p)
    return paths
