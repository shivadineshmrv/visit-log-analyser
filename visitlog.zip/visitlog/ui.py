"""Terminal helpers: ANSI colours, fixed-width tables, pagination, validated prompts."""
import os
import shutil
import sys
from typing import Callable, List, Sequence

from .validation import ValidationError

_USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _USE_COLOR else text


def bold(t): return c(t, "1")
def red(t): return c(t, "31")
def green(t): return c(t, "32")
def yellow(t): return c(t, "33")
def cyan(t): return c(t, "36")


def banner() -> str:
    width = 56
    lines = [
        "=" * width,
        "  WEBSITE VISIT LOG ANALYZER".center(width),
        "  summarize visits by day & referrer".center(width),
        "=" * width,
    ]
    return cyan("\n".join(lines))


def table(headers: Sequence[str], rows: Sequence[Sequence], max_width: int = 26) -> str:
    """Fixed-width text table. Numbers right-aligned, long text truncated."""
    str_rows = [[_trunc(str(cell), max_width) for cell in row] for row in rows]
    widths = [max(len(h), *(len(r[i]) for r in str_rows)) if str_rows else len(h)
              for i, h in enumerate(headers)]
    numeric = [all(_is_num(r[i]) for r in str_rows) and bool(str_rows) for i in range(len(headers))]

    def fmt(cells):
        return " | ".join(cell.rjust(w) if numeric[i] else cell.ljust(w)
                          for i, (cell, w) in enumerate(zip(cells, widths)))

    sep = "-+-".join("-" * w for w in widths)
    return "\n".join([fmt(list(headers)), sep] + [fmt(r) for r in str_rows])


def _trunc(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 1] + "…"


def _is_num(s: str) -> bool:
    try:
        float(s.rstrip("%"))
        return True
    except ValueError:
        return False


def paginate(headers: Sequence[str], rows: List[Sequence], page_size: int = 15) -> None:
    """Print a table page by page; Enter = next, q = stop."""
    if not rows:
        print(yellow("No records to show."))
        return
    total_pages = (len(rows) + page_size - 1) // page_size
    for p in range(total_pages):
        chunk = rows[p * page_size:(p + 1) * page_size]
        print(table(headers, chunk))
        print(f"-- page {p + 1}/{total_pages} ({len(rows)} rows) --")
        if p < total_pages - 1:
            if input("Enter for next page, q to stop: ").strip().lower() == "q":
                break


def ask(prompt: str, validator: Callable[[str], object], default: str = None):
    """Loop until the validator accepts the input. Ctrl-C/EOF cancels (returns None)."""
    suffix = f" [{default}]" if default is not None else ""
    while True:
        try:
            raw = input(f"{prompt}{suffix}: ")
        except (EOFError, KeyboardInterrupt):
            print()
            return None
        if raw.strip() == "" and default is not None:
            raw = default
        try:
            return validator(raw)
        except ValidationError as exc:
            print(red(f"  x {exc}"))


def ask_choice(prompt: str, lo: int, hi: int) -> int:
    while True:
        try:
            raw = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            return 0
        if raw.isdigit() and lo <= int(raw) <= hi:
            return int(raw)
        print(red(f"  x Please enter a number between {lo} and {hi}."))


def confirm(prompt: str) -> bool:
    try:
        return input(f"{prompt} [y/N]: ").strip().lower() in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        return False
