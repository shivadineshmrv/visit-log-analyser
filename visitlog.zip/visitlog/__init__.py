"""Website Visit Log Analyzer - summarize visits by day and referrer."""
__version__ = "1.0.0"
