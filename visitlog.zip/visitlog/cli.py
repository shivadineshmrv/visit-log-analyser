"""Interactive menu-driven terminal interface."""
import os

from . import analytics, plotting, reports
from .storage import Store
from .ui import (ask, ask_choice, banner, bold, confirm, green, paginate, red, table, yellow)
from .validation import (ValidationError, validate_date, validate_duration, validate_page,
                         validate_referrer, validate_time, validate_visitor_id)

DATA_FILE = os.path.join("data", "visits.json")
SAMPLE_CSV = os.path.join("data", "sample_visits.csv")
LEGACY_CSV = os.path.join("data", "legacy_import_with_errors.csv")

MENU = """
 1. Add a visit
 2. List all visits
 3. Search / filter visits
 4. Summary by day
 5. Summary by referrer
 6. Day x Referrer table
 7. Executive summary + warnings
 8. Generate charts (PNG)
 9. Export reports (Markdown / TXT / CSV)
10. Bulk import from CSV
11. Delete a visit
12. Load sample dataset
 0. Exit
"""

VISIT_HEADERS = ["ID", "Date", "Time", "Visitor", "Page", "Referrer", "Dur (s)"]


def visit_rows(visits):
    return [[v.id, v.date, v.time, v.visitor_id, v.page, v.referrer, v.duration_sec] for v in visits]


def add_visit(store: Store) -> None:
    print(bold("\nAdd a visit (Ctrl-C to cancel)"))
    fields = {}
    for key, prompt, fn, default in (
        ("date", "Date YYYY-MM-DD", validate_date, None),
        ("time", "Time HH:MM", validate_time, None),
        ("visitor_id", "Visitor ID", validate_visitor_id, None),
        ("page", "Page path (e.g. /pricing)", validate_page, None),
        ("referrer", "Referrer (blank = direct)", validate_referrer, ""),
        ("duration_sec", "Duration in seconds", validate_duration, None),
    ):
        value = ask(prompt, fn, default)
        if value is None:
            print(yellow("Cancelled."))
            return
        fields[key] = value
    visit = store.add(fields)
    print(green(f"Saved visit #{visit.id}."))


def list_visits(store: Store) -> None:
    paginate(VISIT_HEADERS, visit_rows(sorted(store.visits, key=lambda v: (v.date, v.time))))


def search_visits(store: Store) -> None:
    print(bold("\nSearch / filter (leave a field blank to skip it)"))
    kw = input("Keyword (visitor/page/referrer/date): ").strip()
    ref = input("Exact referrer (e.g. google.com): ").strip()
    ref = validate_referrer(ref) if ref else ""
    page = input("Page contains: ").strip()
    d_from = ask("From date YYYY-MM-DD (blank=any)", lambda s: validate_date(s) if s.strip() else "", "")
    d_to = ask("To date YYYY-MM-DD (blank=any)", lambda s: validate_date(s) if s.strip() else "", "")
    minimum = ask("Minimum duration seconds (blank=any)",
                  lambda s: validate_duration(s) if s.strip() else None, "")
    results = analytics.search(store.visits, kw, ref, page, d_from or "", d_to or "", minimum)
    print(green(f"\n{len(results)} match(es)."))
    paginate(VISIT_HEADERS, visit_rows(results))


def show_by_day(store):
    print(bold("\nVisits by day"))
    print(table(reports.DAY_HEADERS, reports.day_rows(store.visits)) if store.visits else yellow("No data."))


def show_by_referrer(store):
    print(bold("\nVisits by referrer"))
    print(table(reports.REF_HEADERS, reports.ref_rows(store.visits)) if store.visits else yellow("No data."))


def show_matrix(store):
    print(bold("\nVisits by day and referrer"))
    print(reports.matrix_text(store.visits) if store.visits else yellow("No data."))


def show_summary(store):
    print(bold("\nExecutive summary"))
    text = reports.summary_text(store.visits)
    for line in text.splitlines():
        print(yellow(line) if line.strip().startswith("!") else line)


def make_charts(store):
    paths = plotting.make_charts(store.visits)
    if paths:
        print(green("Charts saved:"))
        for p in paths:
            print("  ", p)
    elif not store.visits:
        print(yellow("No data to plot."))
    else:
        print(red("Matplotlib is not installed. Run: pip install matplotlib"))


def export_reports(store):
    paths = reports.export_all(store.visits)
    charts = plotting.make_charts(store.visits)
    print(green("Exported:"))
    for p in paths + charts:
        print("  ", p)
    store.export_csv(os.path.join("output", "all_visits_export.csv"))
    print("  ", os.path.join("output", "all_visits_export.csv"))


def bulk_import(store, default_path=None):
    path = input(f"CSV path [{default_path or SAMPLE_CSV}]: ").strip() or (default_path or SAMPLE_CSV)
    try:
        added, errors = store.import_csv(path)
    except FileNotFoundError:
        print(red(f"File not found: {path}"))
        return
    except (ValidationError, OSError, UnicodeDecodeError) as exc:
        print(red(f"Could not import: {exc}"))
        return
    print(green(f"Imported {added} row(s)."))
    if errors:
        print(yellow(f"{len(errors)} row(s) rejected (details in output/import_errors.log):"))
        for line in errors[:10]:
            print("  ", line)
        if len(errors) > 10:
            print(f"   ... and {len(errors) - 10} more")


def delete_visit(store):
    vid = ask("Visit ID to delete", lambda s: int(s) if s.strip().isdigit() else _bad("Enter a numeric ID."))
    if vid is None:
        return
    if confirm(f"Delete visit #{vid}?"):
        print(green("Deleted.") if store.delete(vid) else red("No visit with that ID."))


def _bad(msg):
    raise ValidationError(msg)


def load_sample(store):
    if store.visits and not confirm("Log is not empty - add sample rows to it?"):
        return
    try:
        added, errors = store.import_csv(SAMPLE_CSV)
        print(green(f"Loaded {added} sample row(s)." + (f" Skipped {len(errors)} duplicate/invalid." if errors else "")))
    except FileNotFoundError:
        print(red(f"Sample file missing: {SAMPLE_CSV}"))


ACTIONS = {
    1: add_visit, 2: list_visits, 3: search_visits, 4: show_by_day, 5: show_by_referrer,
    6: show_matrix, 7: show_summary, 8: make_charts, 9: export_reports,
    10: bulk_import, 11: delete_visit, 12: load_sample,
}


def main() -> None:
    store = Store(DATA_FILE)
    print(banner())
    if store.load_notice:
        print(yellow(store.load_notice))
    print(f"Loaded {len(store.visits)} record(s) from {DATA_FILE}.")
    while True:
        print(MENU)
        choice = ask_choice("Choose an option: ", 0, 12)
        if choice == 0:
            print(green("Data saved. Goodbye!"))
            break
        try:
            ACTIONS[choice](store)
        except KeyboardInterrupt:
            print(yellow("\nCancelled."))
        except ValidationError as exc:
            print(red(f"  x {exc}"))
        except Exception as exc:  # last-resort guard so the demo never crashes
            print(red(f"Unexpected error: {exc}"))
        try:
            input("\nPress Enter to continue...")
        except (EOFError, KeyboardInterrupt):
            break
