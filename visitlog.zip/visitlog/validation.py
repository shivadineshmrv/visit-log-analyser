"""Defensive input validation: every validator returns a cleaned value or raises ValidationError."""
import re
from datetime import date, datetime

MIN_DATE = date(2000, 1, 1)
MAX_DURATION = 86_400  # 24 hours

_VISITOR_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
_PAGE_RE = re.compile(r"^/[^\s]{0,199}$")
_REFERRER_RE = re.compile(r"^[a-z0-9]([a-z0-9.\-]{0,58}[a-z0-9])?$")


class ValidationError(ValueError):
    """Raised when a value fails validation."""


def validate_date(value: str) -> str:
    value = (value or "").strip()
    try:
        d = datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        raise ValidationError("Date must be a real date in YYYY-MM-DD format.")
    if d < MIN_DATE:
        raise ValidationError(f"Date cannot be before {MIN_DATE.isoformat()}.")
    if d > date.today():
        raise ValidationError("Date cannot be in the future.")
    return d.isoformat()


def validate_time(value: str) -> str:
    value = (value or "").strip()
    try:
        t = datetime.strptime(value, "%H:%M")
    except ValueError:
        raise ValidationError("Time must be HH:MM (24-hour), e.g. 14:05.")
    return t.strftime("%H:%M")


def validate_visitor_id(value: str) -> str:
    value = (value or "").strip()
    if not _VISITOR_RE.match(value):
        raise ValidationError("Visitor ID must be 1-32 characters: letters, digits, '_' or '-'.")
    return value


def validate_page(value: str) -> str:
    value = (value or "").strip()
    if not _PAGE_RE.match(value):
        raise ValidationError("Page must start with '/' and contain no spaces (max 200 chars), e.g. /pricing.")
    return value


def validate_referrer(value: str) -> str:
    """Blank -> 'direct'. Strips scheme, 'www.' and paths; lowercases."""
    value = (value or "").strip().lower()
    if value in ("", "-", "none", "direct", "(direct)"):
        return "direct"
    value = re.sub(r"^[a-z]+://", "", value)
    value = value.split("/")[0]
    if value.startswith("www."):
        value = value[4:]
    if not _REFERRER_RE.match(value):
        raise ValidationError("Referrer must be a domain/keyword like 'google.com' (or blank for direct).")
    return value


def validate_duration(value) -> int:
    text = str(value).strip()
    if not re.fullmatch(r"\d+", text):
        raise ValidationError("Duration must be a whole number of seconds (0 or more).")
    n = int(text)
    if n > MAX_DURATION:
        raise ValidationError(f"Duration cannot exceed {MAX_DURATION} seconds (24h).")
    return n


def validate_row(row: dict) -> dict:
    """Validate a whole record (used by bulk import). Collects ALL problems in one error."""
    validators = {
        "date": validate_date,
        "time": validate_time,
        "visitor_id": validate_visitor_id,
        "page": validate_page,
        "referrer": validate_referrer,
        "duration_sec": validate_duration,
    }
    clean, problems = {}, []
    for field, fn in validators.items():
        try:
            clean[field] = fn(row.get(field, ""))
        except ValidationError as exc:
            problems.append(f"{field}: {exc}")
    if problems:
        raise ValidationError("; ".join(problems))
    return clean
